from rest_framework.serializers import ModelSerializer
from .models import UserList

class TestDataSerializer(ModelSerializer):
    class Meta:
        model = UserList
        fields = '__all__'