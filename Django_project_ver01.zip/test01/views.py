from rest_framework.response import Response
from rest_framework.decorators import api_view
from .models import UserList
from .serializers import TestDataSerializer
from django.contrib import auth
from django.contrib.auth import login, authenticate
from django.contrib.auth.models import User
from django.http import HttpResponse
from django.shortcuts import render, redirect
from django.views.decorators.csrf import csrf_exempt
from .form import UserForm, User_Form


@api_view(['GET'])
def getTestDatas(request):
    datas = UserList.objects.all()
    serializer = TestDataSerializer(datas, many=True)
    return Response(serializer.data)

@csrf_exempt
def signup(request):
    if request.method == 'POST':
        form = User_Form(request.POST)
        if form.is_valid():
            UserList = form.save(commit=False)
            UserList.save()
        return redirect('login')
    else:
        form = User_Form()
    return render(request, 'signup.html', {'form':form} )

@csrf_exempt
def login(request):
    form = UserForm()
    return render(request, 'login.html', {'form':form})
