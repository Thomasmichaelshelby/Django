from django import forms
from .models import UserList


class UserForm(forms.ModelForm):
    class Meta:
        model = UserList
        fields = ['user_id', 'user_pw']
        widgets = {
            'user_pw' : forms.PasswordInput
        }

class User_Form(forms.ModelForm):
    user_pw_check = forms.CharField(max_length=40, widget=forms.PasswordInput(attrs={'class':'pw2'}))
    class Meta:
        model = UserList
        fields = ['user_id', 'user_pw', 'user_pw_check', 'user_pn', 'user_em']
        widgets = {
            'user_id':forms.TextInput,
            'user_pw':forms.PasswordInput
        }