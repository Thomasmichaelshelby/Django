DATABASES = {
    'default' : {
        'ENGINE': 'django.db.backends.mysql',
        'NAME': 'project',
        'USER': 'root',
        'PASSWORD': 'chs347',
        'HOST': '127.0.0.1',
        'PORT': '3306',
    }
}